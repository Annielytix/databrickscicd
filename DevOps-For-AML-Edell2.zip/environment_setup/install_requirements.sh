#!/bin/bash
python --version
pip install azure-cli==2.0.46
pip install azureml-sdk[notebooks]==0.1.74
pip install -r requirements.txt